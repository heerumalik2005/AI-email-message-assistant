# groq_service.py
# Handles all Groq API communication for AI Email & Message Assistant

import os
from groq import Groq
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


def get_groq_client():
    """
    Initialize and return a Groq client using the API key from environment.

    Returns:
        Groq: Initialized Groq client instance.

    Raises:
        ValueError: If the API key is missing or not configured.
    """
    api_key = os.getenv("GROQ_API_KEY")

    # Validate API key exists
    if not api_key:
        raise ValueError("GROQ_API_KEY is missing. Please add it to your .env file.")

    if api_key == "replace_with_your_key" or api_key.strip() == "":
        raise ValueError("GROQ_API_KEY is not configured. Please add your actual Groq API key to .env file.")

    return Groq(api_key=api_key)


def generate_message(prompt: str) -> dict:
    """
    Send the constructed prompt to Groq API and return the generated message.

    Args:
        prompt (str): The fully constructed prompt string.

    Returns:
        dict: A dictionary with keys:
              - 'success' (bool): Whether the generation was successful.
              - 'generated_message' (str): The AI-generated message text.
              - 'error' (str): Error description if success is False.
    """
    # Validate prompt is not empty
    if not prompt or prompt.strip() == "":
        return {
            "success": False,
            "generated_message": "",
            "error": "Prompt cannot be empty."
        }

    try:
        # Initialize the Groq client
        client = get_groq_client()

        # Send request to Groq API using a supported model
        chat_completion = client.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert professional writing assistant. "
                        "You transform rough, informal text into polished, well-structured messages. "
                        "Always return only the final improved message without any explanation or commentary."
                    )
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            model="openai/gpt-oss-20b",  # Supported Groq model (free tier)
            temperature=0.7,                   # Balanced creativity and consistency
            max_tokens=1024,                   # Sufficient for email/message length
            top_p=1,
            stream=False
        )

        # Extract the generated text from the response
        generated_text = chat_completion.choices[0].message.content

        # Validate we actually got a response
        if not generated_text or generated_text.strip() == "":
            return {
                "success": False,
                "generated_message": "",
                "error": "AI returned an empty response. Please try again."
            }

        return {
            "success": True,
            "generated_message": generated_text.strip(),
            "error": ""
        }

    except ValueError as ve:
        # API key configuration error
        return {
            "success": False,
            "generated_message": "",
            "error": str(ve)
        }

    except Exception as e:
        # Handle different types of API errors
        error_message = str(e).lower()
        full_error = str(e)

        if "authentication" in error_message or "api_key" in error_message or "invalid_api_key" in error_message:
            return {
                "success": False,
                "generated_message": "",
                "error": "Invalid API key. Please check your GROQ_API_KEY in the .env file."
            }
        elif "rate_limit" in error_message or "rate limit" in error_message:
            return {
                "success": False,
                "generated_message": "",
                "error": "Rate limit reached. Please wait a moment and try again."
            }
        elif "connection" in error_message or "network" in error_message or "timeout" in error_message:
            return {
                "success": False,
                "generated_message": "",
                "error": "Unable to connect to the AI service. Please check your internet connection."
            }
        elif "model" in error_message or "not found" in error_message or "deprecated" in error_message:
            return {
                "success": False,
                "generated_message": "",
                "error": f"Model error: {full_error}"
            }
        else:
            return {
                "success": False,
                "generated_message": "",
                "error": f"Error: {full_error}"
            }


def check_api_key_status() -> dict:
    """
    Check whether the API key is present and properly configured.

    Returns:
        dict: Status of the API key configuration.
    """
    api_key = os.getenv("GROQ_API_KEY")

    if not api_key:
        return {"configured": False, "message": "API key is missing from .env file."}

    if api_key == "replace_with_your_key" or api_key.strip() == "":
        return {"configured": False, "message": "API key is not set. Please add your actual key."}

    return {"configured": True, "message": "API key is configured."}
