# AI Email & Message Assistant

A full-stack AI-powered web application that transforms rough, informal text into professional emails, student messages, leave applications, and formal requests — built with Python Flask and the Groq AI API.

---

## Live Preview

![AI Email & Message Assistant](https://img.shields.io/badge/Status-Active-brightgreen)
![Python](https://img.shields.io/badge/Python-3.8+-blue)
![Flask](https://img.shields.io/badge/Flask-3.1.0-black)
![Groq AI](https://img.shields.io/badge/Powered%20by-Groq%20AI-orange)

---

## Features

- **4 Message Types** — Professional Email, Student Message, Leave Application, Formal Request
- **3 Writing Tones** — Professional, Polite, Friendly
- **Real AI Generation** — Powered by Groq's `llama-3.3-70b-versatile` model
- **Copy to Clipboard** — One-click copy of generated message
- **Download as .txt** — Save your message locally
- **Regenerate** — Get a fresh AI response without re-typing
- **Input Validation** — Both frontend and backend validation
- **Responsive Design** — Works on desktop, tablet, and mobile
- **Error Handling** — Clear user-friendly error messages for all failure cases

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, JavaScript (Fetch API) |
| Backend | Python 3, Flask |
| AI Model | Groq API — llama-3.3-70b-versatile |
| Environment | python-dotenv |

---

## Project Structure

```
AI_Email_Message_Assistant/
│
├── app.py              # Flask app — routes and request handling
├── groq_service.py     # Groq API client and error handling
├── prompts.py          # Prompt builder — categories, tones, instructions
├── requirements.txt    # Python dependencies
├── .env.example        # Sample environment file (safe to share)
├── .gitignore          # Excludes .env and venv from Git
├── README.md           # This file
│
├── templates/
│   └── index.html      # Main webpage
│
└── static/
    ├── style.css       # Responsive styling
    └── script.js       # Frontend logic — fetch, copy, download, clear
```

---

## Getting Started

### Prerequisites

- Python 3.8 or higher
- A free [Groq API key](https://console.groq.com/)

### Installation

**1. Clone the repository**

```bash
git clone https://github.com/yourusername/AI_Email_Message_Assistant.git
cd AI_Email_Message_Assistant
```

**2. Create and activate a virtual environment**

```bash
# Windows
py -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

**3. Install dependencies**

```bash
pip install -r requirements.txt
```

**4. Configure your API key**

Copy the example environment file and add your key:

```bash
cp .env.example .env
```

Open `.env` and replace the placeholder:

```
GROQ_API_KEY=your_actual_groq_api_key_here
```

Get your free API key at [console.groq.com](https://console.groq.com/).

**5. Run the application**

```bash
py app.py
```

**6. Open in browser**

```
http://127.0.0.1:5000
```

---

## How It Works

```
User fills form (type + tone + rough message)
        ↓
JavaScript sends POST /generate to Flask
        ↓
Flask validates input data
        ↓
prompts.py builds a detailed AI prompt
        ↓
groq_service.py calls Groq API
        ↓
AI-generated message returned as JSON
        ↓
JavaScript displays result on the webpage
```

---

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/` | Serves the main web page |
| POST | `/generate` | Generates an AI message |
| GET | `/api/status` | Health check / API key status |

### POST `/generate`

**Request body:**
```json
{
  "message": "i want to ask my teacher about assignment deadline",
  "message_type": "Professional Email",
  "tone": "Professional"
}
```

**Success response:**
```json
{
  "success": true,
  "generated_message": "Subject: Inquiry Regarding Assignment Deadline\n\nDear Professor...",
  "error": ""
}
```

**Error response:**
```json
{
  "success": false,
  "generated_message": "",
  "error": "Please enter your message before generating."
}
```

---

## Example Use Cases

| Input | Type | Output |
|-------|------|--------|
| `i want to ask my teacher about assignment deadline` | Professional Email | Formal email with subject line and proper structure |
| `i have a family function tomorrow so i cannot attend class` | Leave Application | Proper leave application with subject and closing |
| `tell my classmate to send notes from yesterday` | Student Message | Friendly message requesting notes |

---

## Environment Variables

| Variable | Description |
|----------|-------------|
| `GROQ_API_KEY` | Your Groq API key from console.groq.com |

> Never commit your `.env` file. It is already listed in `.gitignore`.

---

## Python Concepts Used

| Concept | Where Used |
|---------|-----------|
| Variables & Data Types | User input, API responses |
| Lists | Message categories, tone options |
| Dictionaries | Category/tone instructions |
| Functions | `build_prompt()`, `generate_message()`, validation |
| Modules | `prompts.py`, `groq_service.py` separated from `app.py` |
| If/elif/else | Input validation, error handling |
| String Operations | Prompt construction, text formatting |
| API Integration | Groq SDK in `groq_service.py` |

---

## License

This project is for educational purposes — Generative AI Course Mini Project.

---

## Author

Built with Flask + Groq AI
