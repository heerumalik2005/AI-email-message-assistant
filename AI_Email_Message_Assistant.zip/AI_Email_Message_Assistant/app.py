# app.py
# Main Flask application for AI Email & Message Assistant

from flask import Flask, render_template, request, jsonify
from prompts import build_prompt, get_categories, get_tones
from groq_service import generate_message, check_api_key_status

# Initialize Flask application
app = Flask(__name__)


# ─────────────────────────────────────────────
# Helper: Input Validation
# ─────────────────────────────────────────────

def validate_generate_request(data: dict) -> tuple:
    """
    Validate incoming JSON data for the /generate route.

    Args:
        data (dict): The parsed JSON request body.

    Returns:
        tuple: (is_valid: bool, error_message: str)
    """
    valid_categories = get_categories()
    valid_tones = get_tones()

    # Check all required fields exist
    required_fields = ["message", "message_type", "tone"]
    for field in required_fields:
        if field not in data:
            return False, f"Missing required field: '{field}'."

    message = data.get("message", "").strip()
    message_type = data.get("message_type", "").strip()
    tone = data.get("tone", "").strip()

    # Validate message is not empty
    if not message:
        return False, "Please enter your message before generating."

    # Validate message length (avoid extremely long inputs)
    if len(message) > 2000:
        return False, "Message is too long. Please keep it under 2000 characters."

    # Validate message_type is one of the accepted values
    if message_type not in valid_categories:
        return False, f"Invalid message type. Choose from: {', '.join(valid_categories)}."

    # Validate tone is one of the accepted values
    if tone not in valid_tones:
        return False, f"Invalid tone. Choose from: {', '.join(valid_tones)}."

    return True, ""


# ─────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────

@app.route("/")
def index():
    """Serve the main frontend page."""
    return render_template("index.html")


@app.route("/generate", methods=["POST"])
def generate():
    """
    API route to generate an improved message using Groq AI.

    Expects JSON body:
        {
            "message": "user's rough text",
            "message_type": "Professional Email",
            "tone": "Professional"
        }

    Returns JSON:
        {
            "success": true/false,
            "generated_message": "...",
            "error": "..."
        }
    """
    # Ensure the request contains JSON
    if not request.is_json:
        return jsonify({
            "success": False,
            "generated_message": "",
            "error": "Invalid request format. JSON data is required."
        }), 400

    data = request.get_json()

    # Validate input data
    is_valid, error_msg = validate_generate_request(data)
    if not is_valid:
        return jsonify({
            "success": False,
            "generated_message": "",
            "error": error_msg
        }), 400

    # Extract validated fields
    message = data["message"].strip()
    message_type = data["message_type"].strip()
    tone = data["tone"].strip()

    # Check API key is configured before calling API
    api_status = check_api_key_status()
    if not api_status["configured"]:
        return jsonify({
            "success": False,
            "generated_message": "",
            "error": "API key is missing or not configured. Please add your GROQ_API_KEY to the .env file."
        }), 500

    # Build the AI prompt using prompts module
    prompt = build_prompt(message_type, tone, message)

    # Call Groq API through groq_service module
    result = generate_message(prompt)

    # Return appropriate HTTP status code based on result
    if result["success"]:
        return jsonify(result), 200
    else:
        return jsonify(result), 500


@app.route("/api/status", methods=["GET"])
def api_status():
    """
    Health check endpoint to verify app and API key status.

    Returns JSON with app status and whether API key is configured.
    """
    key_status = check_api_key_status()
    return jsonify({
        "app": "running",
        "api_key_configured": key_status["configured"],
        "message": key_status["message"]
    }), 200


# ─────────────────────────────────────────────
# Run Application
# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 55)
    print("  AI Email & Message Assistant")
    print("  Powered by Groq AI")
    print("=" * 55)
    print("  Starting server...")
    print("  Open in browser: http://127.0.0.1:5000")
    print("=" * 55)
    app.run(debug=True, host="127.0.0.1", port=5000)
