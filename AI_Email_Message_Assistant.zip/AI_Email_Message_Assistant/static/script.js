// script.js
// Frontend logic for AI Email & Message Assistant

"use strict";

// ─────────────────────────────────────────────
// DOM Element References
// ─────────────────────────────────────────────

const generateForm    = document.getElementById("generateForm");
const messageTypeEl   = document.getElementById("messageType");
const roughMessageEl  = document.getElementById("roughMessage");
const charCountEl     = document.getElementById("charCount");
const generateBtn     = document.getElementById("generateBtn");
const btnContent      = generateBtn.querySelector(".btn-content");
const btnLoading      = generateBtn.querySelector(".btn-loading");

// Input error
const inputError      = document.getElementById("inputError");
const inputErrorMsg   = document.getElementById("inputErrorMsg");

// Output states
const emptyState      = document.getElementById("emptyState");
const loadingState    = document.getElementById("loadingState");
const outputResult    = document.getElementById("outputResult");
const errorState      = document.getElementById("errorState");
const errorMsg        = document.getElementById("errorMsg");

// Output content
const generatedOutput = document.getElementById("generatedOutput");
const outputTypeBadge = document.getElementById("outputTypeBadge");
const outputToneBadge = document.getElementById("outputToneBadge");

// Action buttons
const copyBtn         = document.getElementById("copyBtn");
const downloadBtn     = document.getElementById("downloadBtn");
const regenerateBtn   = document.getElementById("regenerateBtn");
const clearBtn        = document.getElementById("clearBtn");
const retryBtn        = document.getElementById("retryBtn");
const copyFeedback    = document.getElementById("copyFeedback");


// ─────────────────────────────────────────────
// State
// ─────────────────────────────────────────────

let lastRequestData = null;   // Store last request for regenerate
let copyFeedbackTimer = null; // Timer for copy feedback dismissal


// ─────────────────────────────────────────────
// Character Counter
// ─────────────────────────────────────────────

roughMessageEl.addEventListener("input", () => {
  const len = roughMessageEl.value.length;
  const max = 2000;

  charCountEl.textContent = `${len} / ${max}`;

  // Update styling based on character count
  charCountEl.classList.remove("near-limit", "at-limit");
  if (len >= max) {
    charCountEl.classList.add("at-limit");
  } else if (len >= max * 0.85) {
    charCountEl.classList.add("near-limit");
  }

  // Clear input error when user starts typing
  if (len > 0) hideInputError();
});


// ─────────────────────────────────────────────
// Input Validation
// ─────────────────────────────────────────────

/**
 * Validate the form fields before submission.
 * Returns { valid: bool, message: string }
 */
function validateForm() {
  const message     = roughMessageEl.value.trim();
  const messageType = messageTypeEl.value;
  const tone        = document.querySelector('input[name="tone"]:checked');

  if (!message) {
    return { valid: false, message: "Please enter your message before generating." };
  }

  if (message.length < 5) {
    return { valid: false, message: "Message is too short. Please provide more details." };
  }

  if (!messageType) {
    return { valid: false, message: "Please select a message type." };
  }

  if (!tone) {
    return { valid: false, message: "Please select a writing tone." };
  }

  return { valid: true, message: "" };
}

function showInputError(message) {
  inputErrorMsg.textContent = message;
  inputError.classList.remove("hidden");
  roughMessageEl.focus();
}

function hideInputError() {
  inputError.classList.add("hidden");
  inputErrorMsg.textContent = "";
}


// ─────────────────────────────────────────────
// Output State Management
// ─────────────────────────────────────────────

function showState(stateName) {
  emptyState.classList.add("hidden");
  loadingState.classList.add("hidden");
  outputResult.classList.add("hidden");
  errorState.classList.add("hidden");

  if (stateName === "empty")   emptyState.classList.remove("hidden");
  if (stateName === "loading") loadingState.classList.remove("hidden");
  if (stateName === "result")  outputResult.classList.remove("hidden");
  if (stateName === "error")   errorState.classList.remove("hidden");
}


// ─────────────────────────────────────────────
// Generate Button State
// ─────────────────────────────────────────────

function setGenerating(isGenerating) {
  generateBtn.disabled = isGenerating;

  if (isGenerating) {
    btnContent.classList.add("hidden");
    btnLoading.classList.remove("hidden");
    regenerateBtn.disabled = true;
  } else {
    btnContent.classList.remove("hidden");
    btnLoading.classList.add("hidden");
    regenerateBtn.disabled = false;
  }
}


// ─────────────────────────────────────────────
// API Call
// ─────────────────────────────────────────────

/**
 * Send POST /generate to the Flask backend.
 * @param {object} requestData - { message, message_type, tone }
 */
async function callGenerateAPI(requestData) {
  const response = await fetch("/generate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify(requestData)
  });

  const data = await response.json();
  return data;
}


// ─────────────────────────────────────────────
// Main Generate Handler
// ─────────────────────────────────────────────

async function handleGenerate() {
  // 1. Validate form
  const validation = validateForm();
  if (!validation.valid) {
    showInputError(validation.message);
    return;
  }

  hideInputError();

  // 2. Gather data
  const message     = roughMessageEl.value.trim();
  const messageType = messageTypeEl.value;
  const tone        = document.querySelector('input[name="tone"]:checked').value;

  const requestData = {
    message:      message,
    message_type: messageType,
    tone:         tone
  };

  // Store for regenerate
  lastRequestData = requestData;

  // 3. Show loading
  setGenerating(true);
  showState("loading");

  try {
    // 4. Call backend API
    const result = await callGenerateAPI(requestData);

    if (result.success && result.generated_message) {
      // 5a. Show generated result
      displayResult(result.generated_message, messageType, tone);
    } else {
      // 5b. Show error from API
      const errText = result.error || "Something went wrong. Please try again.";
      displayError(errText);
    }

  } catch (networkError) {
    // Network / fetch failure
    displayError("Unable to connect to the server. Please make sure the app is running and try again.");
  } finally {
    setGenerating(false);
  }
}


// ─────────────────────────────────────────────
// Display Helpers
// ─────────────────────────────────────────────

function displayResult(text, messageType, tone) {
  generatedOutput.textContent = text;
  outputTypeBadge.textContent = messageType;
  outputToneBadge.textContent = tone + " Tone";
  hideCopyFeedback();
  showState("result");
}

function displayError(message) {
  errorMsg.textContent = message;
  showState("error");
}


// ─────────────────────────────────────────────
// Form Submit Event
// ─────────────────────────────────────────────

generateForm.addEventListener("submit", (e) => {
  e.preventDefault();
  handleGenerate();
});


// ─────────────────────────────────────────────
// Regenerate
// ─────────────────────────────────────────────

regenerateBtn.addEventListener("click", async () => {
  if (!lastRequestData) return;

  setGenerating(true);
  showState("loading");

  try {
    const result = await callGenerateAPI(lastRequestData);

    if (result.success && result.generated_message) {
      displayResult(
        result.generated_message,
        lastRequestData.message_type,
        lastRequestData.tone
      );
    } else {
      displayError(result.error || "Something went wrong. Please try again.");
    }

  } catch {
    displayError("Unable to connect to the server. Please try again.");
  } finally {
    setGenerating(false);
  }
});


// ─────────────────────────────────────────────
// Retry (from error state)
// ─────────────────────────────────────────────

retryBtn.addEventListener("click", async () => {
  if (!lastRequestData) {
    showState("empty");
    return;
  }

  setGenerating(true);
  showState("loading");

  try {
    const result = await callGenerateAPI(lastRequestData);

    if (result.success && result.generated_message) {
      displayResult(
        result.generated_message,
        lastRequestData.message_type,
        lastRequestData.tone
      );
    } else {
      displayError(result.error || "Something went wrong. Please try again.");
    }

  } catch {
    displayError("Unable to connect to the server. Please try again.");
  } finally {
    setGenerating(false);
  }
});


// ─────────────────────────────────────────────
// Copy Message
// ─────────────────────────────────────────────

copyBtn.addEventListener("click", async () => {
  const text = generatedOutput.textContent;
  if (!text) return;

  try {
    await navigator.clipboard.writeText(text);
    showCopyFeedback();
  } catch {
    // Fallback for browsers without clipboard API
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    textArea.style.opacity = "0";
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand("copy");
    document.body.removeChild(textArea);
    showCopyFeedback();
  }
});

function showCopyFeedback() {
  copyFeedback.classList.remove("hidden");
  if (copyFeedbackTimer) clearTimeout(copyFeedbackTimer);
  copyFeedbackTimer = setTimeout(hideCopyFeedback, 2500);
}

function hideCopyFeedback() {
  copyFeedback.classList.add("hidden");
}


// ─────────────────────────────────────────────
// Download Message
// ─────────────────────────────────────────────

downloadBtn.addEventListener("click", () => {
  const text = generatedOutput.textContent;
  if (!text) return;

  // Build filename from message type
  const typePart = (lastRequestData?.message_type || "message")
    .toLowerCase()
    .replace(/\s+/g, "_");

  const filename = `${typePart}_${getDateStamp()}.txt`;

  // Create download link and trigger it
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url  = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href     = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
});

function getDateStamp() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,"0")}${String(d.getDate()).padStart(2,"0")}`;
}


// ─────────────────────────────────────────────
// Clear
// ─────────────────────────────────────────────

clearBtn.addEventListener("click", clearAll);

function clearAll() {
  // Reset form fields
  roughMessageEl.value   = "";
  messageTypeEl.value    = "";
  charCountEl.textContent = "0 / 2000";
  charCountEl.classList.remove("near-limit", "at-limit");

  // Reset tone to Professional
  const defaultTone = document.querySelector('input[name="tone"][value="Professional"]');
  if (defaultTone) defaultTone.checked = true;

  // Clear errors and output
  hideInputError();
  hideCopyFeedback();
  showState("empty");

  // Clear stored data
  lastRequestData = null;

  // Focus back to textarea
  roughMessageEl.focus();
}


// ─────────────────────────────────────────────
// Keyboard Shortcut: Ctrl+Enter to Generate
// ─────────────────────────────────────────────

roughMessageEl.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
    e.preventDefault();
    handleGenerate();
  }
});


// ─────────────────────────────────────────────
// Init
// ─────────────────────────────────────────────

// Show empty state on page load
showState("empty");
