# prompts.py
# Reusable prompt-building functions for AI Email & Message Assistant

# Available message categories stored in a list
MESSAGE_CATEGORIES = [
    "Professional Email",
    "Student Message",
    "Leave Application",
    "Formal Request"
]

# Available tones stored in a list
WRITING_TONES = [
    "Professional",
    "Polite",
    "Friendly"
]

# Category-specific instructions stored in a dictionary
CATEGORY_INSTRUCTIONS = {
    "Professional Email": (
        "Write a complete professional email with a subject line and proper email structure "
        "(greeting, body paragraphs, closing). Use formal business language."
    ),
    "Student Message": (
        "Write a clear and respectful message suitable for a student addressing a teacher or institution. "
        "Include a proper greeting and closing."
    ),
    "Leave Application": (
        "Write a formal leave application with proper format including date, recipient designation, "
        "subject line, reason for leave, and a polite closing."
    ),
    "Formal Request": (
        "Write a formal request letter with a clear subject, respectful tone, specific request, "
        "and a professional closing."
    )
}

# Tone-specific instructions stored in a dictionary
TONE_INSTRUCTIONS = {
    "Professional": (
        "Use formal, business-appropriate language. Maintain a serious and respectful tone throughout."
    ),
    "Polite": (
        "Use courteous and considerate language. Be respectful and gracious in expression."
    ),
    "Friendly": (
        "Use warm and approachable language while still maintaining respect. "
        "Keep it conversational but appropriate."
    )
}


def build_prompt(message_type: str, tone: str, rough_message: str) -> str:
    """
    Construct a detailed AI prompt based on user selections.

    Args:
        message_type (str): The selected message category.
        tone (str): The selected writing tone.
        rough_message (str): The user's raw/rough input text.

    Returns:
        str: A fully constructed prompt string for the Groq API.
    """

    # Validate inputs using conditional statements
    if message_type not in CATEGORY_INSTRUCTIONS:
        message_type = "Professional Email"

    if tone not in TONE_INSTRUCTIONS:
        tone = "Professional"

    # Get specific instructions for category and tone
    category_instruction = CATEGORY_INSTRUCTIONS[message_type]
    tone_instruction = TONE_INSTRUCTIONS[tone]

    # Build the complete prompt using string operations
    prompt = f"""You are a professional writing assistant. Your task is to transform the rough message below into a polished, well-structured {message_type}.

CATEGORY INSTRUCTIONS:
{category_instruction}

TONE INSTRUCTIONS:
{tone_instruction}

STRICT RULES YOU MUST FOLLOW:
1. Correct all spelling mistakes and grammatical errors.
2. Improve sentence clarity and structure.
3. Preserve the original meaning — do NOT change what the user wants to say.
4. Do NOT invent names, dates, places, or any information not provided by the user.
5. Use placeholders like [Your Name], [Recipient Name], [Date] only where absolutely necessary.
6. Return ONLY the final improved message — no explanations, no commentary, no alternatives.
7. Format the output properly with paragraphs and line breaks.

ROUGH MESSAGE FROM USER:
\"\"\"{rough_message}\"\"\"

Generate the improved {message_type} now:"""

    return prompt


def get_categories() -> list:
    """Return the list of available message categories."""
    return MESSAGE_CATEGORIES


def get_tones() -> list:
    """Return the list of available writing tones."""
    return WRITING_TONES
